import React, { useState } from 'react'

// créer un état par le hooks d'état (useState) actif non actif
// quand on clique sur l'item on change l'état
// selon l'état on applique une class css actif ou non actif

const Item = ({ title }) => {
    const [done, toogleDone] = useState(false)

    const changeItemState = () => {
        //si l'item est en "done true" on le passe en "done false"
        if (done === true)
            toogleDone(false)
        else
            toogleDone(true)

    return (
        <div >
            {title}
        </div>
    )
}

export default Item

